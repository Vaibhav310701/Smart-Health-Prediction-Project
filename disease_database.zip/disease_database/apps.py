from django.apps import AppConfig


class DiseaseDatabaseConfig(AppConfig):
    name = 'disease_database'
